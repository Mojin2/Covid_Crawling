#include <stdio.h>

int main(void)
{
	int x = 0x00000001;
	char *c = (char*) &x;

	if (*c == 0x01)
	{
		printf("It's Little-Endian\n");
	}
	else 
	{
		printf("It's Big-Endian\n");
	}

	
	if (sizeof(long) == 4)
	{
		printf("The system is 32bit!\n");
	}
	else
	{
		printf("The system is 64bit!\n");
	}

	return 0;

}
